import { useState } from 'react'
import Main from './components/main'
import Post from './components/post'
import Fworks from './components/fworks'

function App() {
  return (
    
    <div id='content'>
      
      <Main/>
      <Post/>
      <Fworks/>
    </div>
  )
}

export default App

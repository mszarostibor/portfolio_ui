import { useState } from 'react'
import Main from './components/main'
import Post from './components/post'
import Fworks from './components/fworks'

function App() {
  return (
    <div>
      <div id='content'>
        <Main/>
      </div>  
        <Post/>
        <Fworks/>
    </div>
  )
}

export default App

export default function Post(){
    return(
        <div className="post" id="content">
            <div className="card_grid">
                <p id="alcim">Recent posts</p>
                <p id="vall">View all</p>
            </div>
            <div className="card-container">
                <div className="card">
                    <h1>Making a design system from scratch</h1>
                    <p>12 Feb 2020 | Design, Pattern</p>
                    <p>Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.</p>
                </div>
                <div className="card">
                    <h1>Creating pixel perfect icons in Figma</h1>
                    <p>12 Feb 2020 | Figma, Icon Design</p>
                    <p>Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.</p>
                </div>
            </div>
        </div>
    )
}
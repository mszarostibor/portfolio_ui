export default function Post(){
    return(
        <div>
            <h2>Recent posts</h2>
            <p>View all</p>
            <div>
                <h1>Making a design system from scratch</h1>
                <p>12 Feb 2020</p>
                <p>|</p>
                <p>Design, Pattern</p>
                <p>Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.</p>
            </div>
            <div>
                <h1>Creating pixel perfect icons in Figma</h1>
                <p>12 Feb 2020</p>
                <p>|</p>
                <p>Figma, Icon Design</p>
                <p>Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet.</p>
            </div>
        </div>
    )
}
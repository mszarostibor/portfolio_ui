import kep1 from "../assets/icons/facebook.svg"
import kep2 from "../assets/icons/instagram.svg"
import kep3 from "../assets/icons/linkedin.svg"
import kep4 from "../assets/icons/twitter.svg"

export default function Footer(){
    return(
        <div>
            <div>
                <img src={kep1} alt="facebook" />
                <img src={kep2} alt="instagram" />
                <img src={kep3} alt="linkedin" />
                <img src={kep4} alt="twitter" />
            </div>
            <p>Copyright ©2020 All rights reserved</p>
        </div>
    )
}
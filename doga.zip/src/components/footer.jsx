import kep1 from "../assets/icons/facebook.svg"
import kep2 from "../assets/icons/instagram.svg"
import kep3 from "../assets/icons/linkedin.svg"
import kep4 from "../assets/icons/twitter.svg"

export default function Footer(){
    return(
        <div className="footer">
            <div>
                <img src={kep1} alt="facebook" className="footer_kep"/>
                <img src={kep2} alt="instagram" className="footer_kep"/>
                <img src={kep4} alt="twitter" className="footer_kep"/>
                <img src={kep3} alt="linkedin" className="footer_kep"/>
            </div>
            <p>Copyright ©2020 All rights reserved</p>
        </div>
    )
}
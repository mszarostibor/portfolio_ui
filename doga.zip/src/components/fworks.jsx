import kep1 from "../assets/index-blog-post-images/designing-dashboards.png"
import kep2 from "../assets/index-blog-post-images/vibrant-portraits.png"
import kep3 from "../assets/index-blog-post-images/malayalam-type.png"

import Fworks_card from "./fworks_card";

export default function Fworks(){
    return(
        <div id="content">
            <p id="alcim">Featured works</p>
            <Fworks_card kep={kep1} cim={"Designing Dashboards"} ev={"2020"} alcim={"Dashboard"} tartalom={"Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet."}/>
            <Fworks_card kep={kep2} cim={"Vibrant Portraits of 2020"} ev={"2018"} alcim={"Illustration"} tartalom={"Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet."}/>
            <Fworks_card kep={kep3} cim={"36 Days of Malayalam type"} ev={"2018"} alcim={"Typography"} tartalom={"Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. Exercitation veniam consequat sunt nostrud amet."}/>
        </div>
    )
}
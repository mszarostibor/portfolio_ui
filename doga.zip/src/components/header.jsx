import { NavLink } from "react-router";

export default function Header(){
    return(
        <div className="menu_right">
            <NavLink to="/works">Works</NavLink>
            <NavLink to="/blog">Blog</NavLink>
            <NavLink to="/contact">Contact</NavLink>
        </div>
    )
}
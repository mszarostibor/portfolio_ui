export default function Fworks_card({kep, cim, ev, alcim, tartalom}){
    return(
        <div>
            <div>
                <img src={kep} alt="kep" />
            </div>
            <div>
                <h1>{cim}</h1>
                <p>{ev}</p>
                <p>{alcim}</p>
                <p>{tartalom}</p>
            </div>
            <hr />
        </div>
    )
}
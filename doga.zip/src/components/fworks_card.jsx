export default function Fworks_card({kep, cim, ev, alcim, tartalom}){
    return(
        <div>
            <div className="card-container">
                <div>
                    <img src={kep} alt="kep" id="fkep"/>
                </div>
                <div className="fszoveg">
                    <h1>{cim}</h1>
                    <p><span id="fev"> {ev} </span> <span id="falcim">{alcim}</span></p>
                    <p>{tartalom}</p>
                </div>
            </div>
            <hr />
        </div>
    )
}
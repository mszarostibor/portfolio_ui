export default function Blog(){
    return(
        <div>
            
        </div>
    )
}